Hello!

So, as you may remember, up until this point, my code was all in one large file.
I had meant to divide it but then I kept putting it off and next thing I knew, the end of Paint was here.

I will cut to the chase. Do you want the good news or bad news first.
The good news is I have finally divided my code into smaller more edible chunks.
The bad news is that this may have caused some unforseen hiccups within the code that I had not previously forseen.

Therefore, I have ALSO included a Failsafe folder containing a single imageEdit.java function that will definitely 100% work.
I am aware that the point of this assessment is more towards how well-structured my code is, which I believe it is. However, functionality is also
important, hence the failsafe for "proof of functionality".