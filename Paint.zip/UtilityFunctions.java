import java.awt.*;
import java.awt.image.BufferedImage;
import javax.swing.*;

public class UtilityFunctions {

    /**
     * Opens a color chooser dialog for selecting the drawing color.
     *
     * @param currentColor The current color.
     * @return The selected color.
     */
    public static Color selectColor(Color currentColor) {
        Color selectedColor = JColorChooser.showDialog(null, "Select Color", currentColor);
        if (selectedColor != null) {
            return selectedColor;
        }
        return currentColor;
    }

    /**
     * Displays information about the current drawing color, including name, hex, and RGB values.
     *
     * @param currentColor The current drawing color.
     */
    public static void showColorInfo(Color currentColor) {
        String colorName = getColorName(currentColor);
        String hexValue = String.format("#%02X%02X%02X", currentColor.getRed(), currentColor.getGreen(), currentColor.getBlue());
        String rgbValue = String.format("RGB(%d, %d, %d)", currentColor.getRed(), currentColor.getGreen(), currentColor.getBlue());
        String colorInfo = "Color Name: " + colorName + "\n"
                + "Hex Value: " + hexValue + "\n"
                + "RGB Value: " + rgbValue;
        JOptionPane.showMessageDialog(null, colorInfo, "Color Info", JOptionPane.INFORMATION_MESSAGE);
    }

    /**
     * Gets the English name for a color based on its RGB value.
     *
     * @param color The color for which to determine the name.
     * @return The English name of the color.
     */
    public static String getColorName(Color color) {
        if (color.equals(Color.BLACK)) {
            return "Black";
        } else if (color.equals(Color.RED)) {
            return "Red";
        } else if (color.equals(Color.GREEN)) {
            return "Green";
        } else if (color.equals(Color.BLUE)) {
            return "Blue";
        } else {
            return "Custom Color";
        }
    }

    // Additional utility functions can be added here as needed
}
