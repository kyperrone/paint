import java.awt.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import javax.swing.*;
import java.io.File;
import java.io.IOException;

public class FileOperations {

    /**
     * Loads and displays an image from a specified file.
     *
     * @param selectedFile The file containing the image to be loaded and displayed.
     * @param imageLabel The label to display the loaded image.
     * @throws IOException If an error occurs while loading the image.
     */
    public static void loadAndDisplayImage(File selectedFile, JLabel imageLabel) throws IOException {
        String format = UtilityFunctions.getFileFormat(selectedFile); // Assuming UtilityFunctions contains this method
        if (format != null) {
            BufferedImage loadedImage = ImageIO.read(selectedFile);
            ImageIcon imageIcon = new ImageIcon(loadedImage);
            imageLabel.setIcon(imageIcon);
        } else {
            JOptionPane.showMessageDialog(null, "Unsupported image format.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Saves the current image. Prompts the user to choose a location if necessary.
     *
     * @param currentImage The image to save.
     * @param savedFile The file to save the image to.
     */
    public static void saveImage(BufferedImage currentImage, File savedFile) {
        if (currentImage != null && savedFile != null) {
            try {
                String format = UtilityFunctions.getFileFormat(savedFile); // Assuming UtilityFunctions contains this method
                ImageIO.write(currentImage, format, savedFile);
                JOptionPane.showMessageDialog(null, "Image saved successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
            } catch (IOException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error saving image.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            // Logic for prompting user to choose a save location
        }
    }

    /**
     * Starts a new drawing, clearing the canvas and resetting various parameters.
     *
     * @param imageLabel The label displaying the drawing.
     * @param screenSize The size of the screen, used to set canvas dimensions.
     * @return A new blank canvas.
     */
    public static BufferedImage startNewDrawing(JLabel imageLabel, Dimension screenSize) {
        int canvasWidth = screenSize.width;
        int canvasHeight = screenSize.height;
        BufferedImage newDrawing = new BufferedImage(canvasWidth, canvasHeight, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = newDrawing.createGraphics();
        g2d.setColor(new Color(0, 0, 0, 0)); // Transparent color
        g2d.fillRect(0, 0, canvasWidth, canvasHeight);
        g2d.dispose();

        imageLabel.setIcon(new ImageIcon(newDrawing));
        imageLabel.setPreferredSize(new Dimension(canvasWidth, canvasHeight));
        imageLabel.revalidate();

        return newDrawing;
    }

    // Additional file operations can be added here as needed
}
