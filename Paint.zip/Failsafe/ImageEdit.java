import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.KeyStroke;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.util.Stack;
import java.awt.event.ActionListener;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JComponent;
import javax.swing.JFrame;


/**
 * This class represents an image editing application with various features
 * for drawing, selecting colors, saving images, and more.
 */
public class ImageEdit extends JFrame { // create frame
    private final JLabel imageLabel; // Create label to hold image
    private BufferedImage drawingImage; // Duplicate image to allow draw function
    private BufferedImage currentImage; // Keeps track of currently opened image
    private File savedFile; // Keeps track of if file has been saved yet
    private final JMenuBar menuBar; // New menu
    private final JMenu fileMenu; // Menu bar contents
    private final JMenu helpMenu; // Help menu contents
    private final JMenu optionsMenu; // Options menu
    private JMenu shapesMenu; // Shapes menu
    private final JMenuItem saveAsMenuItem; // Save as button
    private final JMenuItem saveMenuItem; // Save button
    private final JMenuItem helpMenuItem; // Help menu item
    private final JSlider lineWidthSlider; // Line width slider
    private boolean isDrawing = false; // Variable to detect if mouse is drawing
    private int prevX, prevY; // Previous mouse location
    private int startX, startY; // Starting mouse location
    private int lineWidth = 2; // Default line width
    private JCheckBox displayAutosaveCheckbox;

    public enum Shape {LINE, SQUARE, CIRCLE, RECTANGLE, ELLIPSE, TRIANGLE, FREEHAND, POINTER, TEXT, ERASE, POLYGON}// Enumerators for Shapes menu

    private ImageEdit.Shape selectedShape = ImageEdit.Shape.FREEHAND; // Default to Freehand
    private boolean unsavedChanges = false; // Flag for smart save
    private Color drawingColor = Color.BLACK; // Default drawing color
    private Stroke dashedLineStroke = null; // Initialize as null for solid lines
    private final int eraserWidth = 10; // Default eraser width
    private int polygonSides = 3; // Default to triangle
    private final Stack<BufferedImage> undoStack;
    private final Stack<BufferedImage> redoStack;
    private BufferedImage clipboardImage;
    private boolean isSelecting = false;
    private int selectionStartX, selectionStartY, selectionEndX, selectionEndY;
    private boolean isSelectionMode = false;
    private Timer autosaveTimer;
    private JFrame autosaveTimerWindow;
    private boolean autosaveTimerVisible = false;
    private Timer autosaveUpdateTimer;
    private int autosaveTimeInSeconds = 0;
    private boolean autosaveNotificationEnabled = true;

    public ImageEdit() {
        setTitle("Pain(t)"); // Set window parameters
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setLayout(new FlowLayout(FlowLayout.LEFT, 10, 10));

        drawingImage = new BufferedImage(800, 600, BufferedImage.TYPE_INT_ARGB); // Initialize drawingImage

        undoStack = new Stack<>();
        redoStack = new Stack<>();

        // Initialize the autosaveTimer
        autosaveTimer = new Timer(30000, e -> autosave()); // 30,000 milliseconds = 30 seconds
        autosaveTimer.start();

        BufferedImage previousState = deepCopy(drawingImage); // Create a deep copy of the current state
        undoStack.push(previousState);

        menuBar = new JMenuBar(); // Create and put on frame menu bar
        setJMenuBar(menuBar);

        fileMenu = new JMenu("File"); // Create and add 'file' menu category
        menuBar.add(fileMenu);

        saveAsMenuItem = new JMenuItem("Save As"); // Create and add save as button
        fileMenu.add(saveAsMenuItem);
        saveAsMenuItem.addActionListener(e -> saveAsImage());
        saveAsMenuItem.setToolTipText("Save image to location");

        saveMenuItem = new JMenuItem("Save"); // Create and add save button
        fileMenu.add(saveMenuItem);
        saveMenuItem.addActionListener(e -> saveImage());
        saveMenuItem.setToolTipText("Save the current image");

        optionsMenu = new JMenu("Options"); // Create and add options menu
        menuBar.add(optionsMenu);

        JMenuItem startNewMenuItem = new JMenuItem("Start New");
        fileMenu.add(startNewMenuItem);
        startNewMenuItem.addActionListener(e -> startNewDrawing());
        startNewMenuItem.setToolTipText("Start new drawing");

        JButton colorButton = new JButton("Select Color"); // Create and add color picker
        optionsMenu.add(colorButton);
        colorButton.addActionListener(e -> selectColor());
        colorButton.setToolTipText("Select Color");

        displayAutosaveCheckbox = new JCheckBox("Display Autosave");
        optionsMenu.add(displayAutosaveCheckbox);
        displayAutosaveCheckbox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                boolean displayAutosave = displayAutosaveCheckbox.isSelected();
                autosaveNotificationEnabled = displayAutosave;
            }
        });

        optionsMenu.add(new JLabel("Line Width:"));
        lineWidthSlider = new JSlider(JSlider.HORIZONTAL, 1, 10, lineWidth); // Create and add line width slider
        optionsMenu.add(lineWidthSlider);
        lineWidthSlider.addChangeListener(e -> {
            lineWidth = lineWidthSlider.getValue();
        });
        lineWidthSlider.setToolTipText("Change drawing width");

        shapesMenu = new JMenu("Shapes"); // Create and add Shapes menu
        menuBar.add(shapesMenu);

        // Add a separate line width slider for shape drawing under the "Shapes" tab
        JSlider shapeLineWidthSlider = new JSlider(JSlider.HORIZONTAL, 1, 10, lineWidth);
        shapesMenu.add(new JLabel("Line Width:"));
        shapesMenu.add(shapeLineWidthSlider);
        shapeLineWidthSlider.addChangeListener(e -> {
            lineWidth = shapeLineWidthSlider.getValue();
        });

        JMenuItem lineMenuItem = new JMenuItem("Line", createShapeIcon(30, 30, ShapeType.LINE)); // Create all items in Shapes menu
        shapesMenu.add(lineMenuItem);
        lineMenuItem.addActionListener(e -> selectedShape = ImageEdit.Shape.LINE);
        lineMenuItem.setToolTipText("Draw a line");

        JMenuItem squareMenuItem = new JMenuItem("Square", createShapeIcon(30, 30, ShapeType.SQUARE));
        shapesMenu.add(squareMenuItem);
        squareMenuItem.addActionListener(e -> selectedShape = ImageEdit.Shape.SQUARE);
        squareMenuItem.setToolTipText("Draw a square");

        JMenuItem circleMenuItem = new JMenuItem("Circle", createShapeIcon(30, 30, ShapeType.CIRCLE));
        shapesMenu.add(circleMenuItem);
        circleMenuItem.addActionListener(e -> selectedShape = ImageEdit.Shape.CIRCLE);
        circleMenuItem.setToolTipText("Draw a circle");

        JMenuItem rectangleMenuItem = new JMenuItem("Rectangle", createShapeIcon(30, 20, ShapeType.RECTANGLE));
        shapesMenu.add(rectangleMenuItem);
        rectangleMenuItem.addActionListener(e -> selectedShape = ImageEdit.Shape.RECTANGLE);
        rectangleMenuItem.setToolTipText("Draw a rectangle");

        JMenuItem ellipseMenuItem = new JMenuItem("Ellipse", createShapeIcon(30, 30, ShapeType.ELLIPSE));
        shapesMenu.add(ellipseMenuItem);
        ellipseMenuItem.addActionListener(e -> selectedShape = ImageEdit.Shape.ELLIPSE);
        ellipseMenuItem.setToolTipText("Draw an ellipse");

        JMenuItem triangleMenuItem = new JMenuItem("Triangle", createShapeIcon(30, 30, ShapeType.TRIANGLE));
        shapesMenu.add(triangleMenuItem);
        triangleMenuItem.addActionListener(e -> selectedShape = ImageEdit.Shape.TRIANGLE);
        triangleMenuItem.setToolTipText("Draw a triangle");

        JMenuItem freehandMenuItem = new JMenuItem("Freehand", createFreehandIcon()); // Added Freehand shape
        shapesMenu.add(freehandMenuItem);
        freehandMenuItem.addActionListener(e -> selectedShape = ImageEdit.Shape.FREEHAND);
        freehandMenuItem.setToolTipText("Draw freehand");

        // Inside the constructor, add the following lines:
        JMenuItem polygonMenuItem = new JMenuItem("Polygon", createShapeIcon(30, 30, ShapeType.POLYGON));
        shapesMenu.add(polygonMenuItem);
        polygonMenuItem.setToolTipText("Draw a polygon");
        polygonMenuItem.addActionListener(e -> {
            String sidesInput = JOptionPane.showInputDialog(this, "Enter the number of sides for the polygon:");
            try {
                polygonSides = Integer.parseInt(sidesInput);
            } catch (NumberFormatException ex) {
                // Handle invalid input or cancel action
            }
            selectedShape = ImageEdit.Shape.POLYGON;
        });

        JMenuItem pointMenuItem = new JMenuItem("Pointer", createShapeIcon(30, 30, ShapeType.POINTER));
        shapesMenu.add(pointMenuItem);
        pointMenuItem.addActionListener(e -> selectedShape = ImageEdit.Shape.POINTER);
        pointMenuItem.setToolTipText("Draw a pointer");

        // Add a menu item for toggling dashed lines under the "Shapes" tab
        JCheckBoxMenuItem dashedLinesMenuItem = new JCheckBoxMenuItem("Dashed Lines");
        shapesMenu.add(dashedLinesMenuItem);
        dashedLinesMenuItem.setToolTipText("Toggle dashed shapes");
        dashedLinesMenuItem.addActionListener(e -> toggleDashedLines(dashedLinesMenuItem.isSelected()));

        JMenuItem textMenuItem = new JMenuItem("Text");
        shapesMenu.add(textMenuItem);
        textMenuItem.addActionListener(e -> selectedShape = ImageEdit.Shape.TEXT);
        textMenuItem.setToolTipText("Insert text");

        JMenu editMenu = new JMenu("Edit"); // Create and add 'edit' menu category
        menuBar.add(editMenu);

        // Create an Action for the "Cut" operation
        Action cutAction = new AbstractAction("Cut") {
            @Override
            public void actionPerformed(ActionEvent e) {
                startSelection(); // Start the selection
            }
        };
        cutAction.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke(KeyEvent.VK_X, Toolkit.getDefaultToolkit().getMenuShortcutKeyMaskEx()));
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put((KeyStroke) cutAction.getValue(Action.ACCELERATOR_KEY), "cutAction");
        getRootPane().getActionMap().put("cutAction", cutAction);
        JMenuItem cutMenuItem = new JMenuItem(cutAction);
        editMenu.add(cutMenuItem);
        cutMenuItem.setToolTipText("Cut area from image");

        Action pasteAction = new AbstractAction("Paste") {
            @Override
            public void actionPerformed(ActionEvent e) {
                pasteClipboardImage();
            }
        };
        pasteAction.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke(KeyEvent.VK_V, Toolkit.getDefaultToolkit().getMenuShortcutKeyMaskEx()));
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put((KeyStroke) pasteAction.getValue(Action.ACCELERATOR_KEY), "pasteAction");
        getRootPane().getActionMap().put("pasteAction", pasteAction);
        JMenuItem pasteMenuItem = new JMenuItem(pasteAction);
        editMenu.add(pasteMenuItem);
        pasteMenuItem.setToolTipText("Paste region from image");

        // Add a menu item for erasing under the "Shapes" tab
        JMenuItem eraseMenuItem = new JMenuItem("Erase");
        optionsMenu.add(eraseMenuItem);
        eraseMenuItem.addActionListener(e -> selectedShape = ImageEdit.Shape.ERASE);
        eraseMenuItem.setToolTipText("Erase markings/shapes");

        helpMenu = new JMenu("Help"); // Create and add 'help' menu category
        menuBar.add(helpMenu);

        helpMenuItem = new JMenuItem("Help"); // Create and add help button
        helpMenu.add(helpMenuItem);
        helpMenuItem.addActionListener(e -> showHelp());
        helpMenuItem.setToolTipText("Show help menu");

        JMenuItem colorInfoMenuItem = new JMenuItem("Color Info"); // Create and add color info menu item
        helpMenu.add(colorInfoMenuItem);
        colorInfoMenuItem.addActionListener(e -> showColorInfo());
        colorInfoMenuItem.setToolTipText("Show info on current color");

        JMenuItem toggleAutosaveTimerMenuItem = new JMenuItem("Toggle Autosave Timer");
        toggleAutosaveTimerMenuItem.addActionListener(e -> toggleAutosaveTimerWindow());
        helpMenu.add(toggleAutosaveTimerMenuItem);
        toggleAutosaveTimerMenuItem.setToolTipText("Toggle autosave display");

        imageLabel = new JLabel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (drawingImage != null) {
                    g.drawImage(drawingImage, 0, 0, this);
                }
            }
        };

        // Determine the screen size
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();

        // Create the JScrollPane and set its preferred size to fit the screen borders with some padding
        int padding = 20; // Adjust the padding as needed
        JScrollPane scrollPane = new JScrollPane(imageLabel, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setPreferredSize(new Dimension(screenSize.width - padding, screenSize.height - padding));
        getContentPane().add(scrollPane);

        JFileChooser fileChooser = new JFileChooser();
        int result = fileChooser.showOpenDialog(this);

        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            savedFile = fileChooser.getSelectedFile();
            try {
                loadAndDisplayImage(selectedFile);
            } catch (IOException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error loading image.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }

        imageLabel.addMouseListener(new MouseAdapter() { // Mouse listeners for button press/release
            @Override
            public void mousePressed(MouseEvent e) {
                isDrawing = true;
                startX = e.getX();
                startY = e.getY();
                prevX = e.getX();
                prevY = e.getY();
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                isDrawing = false;
                drawShape();
            }
        });

        imageLabel.addMouseMotionListener(new MouseMotionAdapter() { // Mouse listeners for drawing/shapes
            @Override
            public void mouseDragged(MouseEvent e) {
                if (isDrawing) {
                    int x = e.getX();
                    int y = e.getY();
                    Graphics2D g2d = (Graphics2D) drawingImage.getGraphics();
                    g2d.setColor(drawingColor);
                    g2d.setStroke(new BasicStroke(lineWidth));

                    // Draw the freehand line segment
                    if (selectedShape == ImageEdit.Shape.FREEHAND) {
                        g2d.drawLine(prevX, prevY, x, y);
                    }
                    g2d.dispose();
                    imageLabel.repaint();
                    prevX = x;
                    prevY = y;
                    unsavedChanges = true; // Mark changes as unsaved
                }
            }
        });

        imageLabel.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                if (selectedShape == ImageEdit.Shape.ERASE) {
                    int x = e.getX();
                    int y = e.getY();
                    Graphics2D g2d = (Graphics2D) drawingImage.getGraphics();
                    g2d.setComposite(AlphaComposite.Clear);
                    g2d.fillRect(x - (eraserWidth / 2), y - (eraserWidth / 2), eraserWidth, eraserWidth);
                    g2d.dispose();
                    imageLabel.repaint();
                    unsavedChanges = true; // Mark changes as unsaved
                }
            }
        });
        // Smart save on window close
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                closeWindow();
            }
        });
        pack();
        setLocationRelativeTo(null);

        // Create an Action for color info
        Action colorInfoAction = new AbstractAction("Color Info") {
            @Override
            public void actionPerformed(ActionEvent e) {
                showColorInfo();
            }
        };
        // Register "Ctrl + I" key binding for color info
        colorInfoAction.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke(KeyEvent.VK_I, Toolkit.getDefaultToolkit().getMenuShortcutKeyMaskEx()));
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put((KeyStroke) colorInfoAction.getValue(Action.ACCELERATOR_KEY), "colorInfoAction");
        getRootPane().getActionMap().put("colorInfoAction", colorInfoAction);

        // Create an Action for "Save As"
        Action saveAsAction = new AbstractAction("Save As") {
            @Override
            public void actionPerformed(ActionEvent e) {
                saveAsImage();
            }
        };
        // Register "Ctrl + Shift + S" key binding for "Save As"
        saveAsAction.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke(KeyEvent.VK_S, Toolkit.getDefaultToolkit().getMenuShortcutKeyMaskEx() | KeyEvent.SHIFT_DOWN_MASK));
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put((KeyStroke) saveAsAction.getValue(Action.ACCELERATOR_KEY), "saveAsAction");
        getRootPane().getActionMap().put("saveAsAction", saveAsAction);

        // Register "Ctrl + S" key binding for saving
        Action saveAction = new AbstractAction("Save") {
            @Override
            public void actionPerformed(ActionEvent e) {
                saveImage();
            }
        };
        saveAction.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke(KeyEvent.VK_S, Toolkit.getDefaultToolkit().getMenuShortcutKeyMaskEx()));
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put((KeyStroke) saveAction.getValue(Action.ACCELERATOR_KEY), "saveAction");
        getRootPane().getActionMap().put("saveAction", saveAction);

        // Create an Action for help
        Action helpAction = new AbstractAction("Help") {
            @Override
            public void actionPerformed(ActionEvent e) {
                showHelp();
            }
        };
        // Register "Ctrl + H" key binding for help
        helpAction.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke(KeyEvent.VK_H, Toolkit.getDefaultToolkit().getMenuShortcutKeyMaskEx()));
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put((KeyStroke) helpAction.getValue(Action.ACCELERATOR_KEY), "helpAction");
        getRootPane().getActionMap().put("helpAction", helpAction);

        // Create an Action for opening the color selector
        Action colorSelectorAction = new AbstractAction("Color Selector") {
            @Override
            public void actionPerformed(ActionEvent e) {
                selectColor();
            }
        };
        // Register "Ctrl + Shift + C" key binding for opening the color selector
        colorSelectorAction.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke(KeyEvent.VK_C, Toolkit.getDefaultToolkit().getMenuShortcutKeyMaskEx() | KeyEvent.SHIFT_DOWN_MASK));
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put((KeyStroke) colorSelectorAction.getValue(Action.ACCELERATOR_KEY), "colorSelectorAction");
        getRootPane().getActionMap().put("colorSelectorAction", colorSelectorAction);

        // Create an Action for "Start New"
        Action startNewAction = new AbstractAction("Start New") {
            @Override
            public void actionPerformed(ActionEvent e) {
                startNewDrawing();
            }
        };
        // Register "Ctrl + N" key binding for "Start New"
        startNewAction.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke(KeyEvent.VK_N, Toolkit.getDefaultToolkit().getMenuShortcutKeyMaskEx()));
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put((KeyStroke) startNewAction.getValue(Action.ACCELERATOR_KEY), "startNewAction");
        getRootPane().getActionMap().put("startNewAction", startNewAction);

        // In the constructor, add the following code to bind keyboard shortcuts:
        Action undoAction = new AbstractAction("Undo") {
            @Override
            public void actionPerformed(ActionEvent e) {
                undo();
            }
        };
        undoAction.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke(KeyEvent.VK_Z, Toolkit.getDefaultToolkit().getMenuShortcutKeyMaskEx()));
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put((KeyStroke) undoAction.getValue(Action.ACCELERATOR_KEY), "undoAction");
        getRootPane().getActionMap().put("undoAction", undoAction);

        Action redoAction = new AbstractAction("Redo") {
            @Override
            public void actionPerformed(ActionEvent e) {
                redo();
            }
        };
        redoAction.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke(KeyEvent.VK_Y, Toolkit.getDefaultToolkit().getMenuShortcutKeyMaskEx()));
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put((KeyStroke) redoAction.getValue(Action.ACCELERATOR_KEY), "redoAction");
        getRootPane().getActionMap().put("redoAction", redoAction);

        // Define an action for rotating the image 90 degrees clockwise
        Action rotateImageAction = new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (currentImage != null) {
                    currentImage = rotateImage(currentImage, 90);
                    ImageIcon imageIcon = new ImageIcon(currentImage);
                    imageLabel.setIcon(imageIcon);
                    imageLabel.repaint();
                    unsavedChanges = true; // Mark changes as unsaved
                }
            }
        };
        // Bind the Ctrl + R key combination to the rotateImageAction
        KeyStroke ctrlRKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_R, KeyEvent.CTRL_DOWN_MASK);
        imageLabel.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(ctrlRKeyStroke, "rotateImage");
        imageLabel.getActionMap().put("rotateImage", rotateImageAction);

        // Define an action for flipping the image over the Y-axis
        Action flipImageAction = new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (currentImage != null) {
                    currentImage = flipImageY(currentImage);
                    ImageIcon imageIcon = new ImageIcon(currentImage);
                    imageLabel.setIcon(imageIcon);
                    imageLabel.repaint();
                    unsavedChanges = true; // Mark changes as unsaved
                }
            }
        };
        // Bind the Ctrl + L key combination to the flipImageAction
        KeyStroke ctrlLKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_L, KeyEvent.CTRL_DOWN_MASK);
        imageLabel.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(ctrlLKeyStroke, "flipImage");
        imageLabel.getActionMap().put("flipImage", flipImageAction);

        // Define an action for flipping the image over the X-axis
        Action flipImageXAction = new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (currentImage != null) {
                    currentImage = flipImageX(currentImage);
                    ImageIcon imageIcon = new ImageIcon(currentImage);
                    imageLabel.setIcon(imageIcon);
                    imageLabel.repaint();
                    unsavedChanges = true; // Mark changes as unsaved
                }
            }
        };
        // Bind the Ctrl + K key combination to the flipImageXAction
        KeyStroke ctrlKKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_K, KeyEvent.CTRL_DOWN_MASK);
        imageLabel.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(ctrlKKeyStroke, "flipImageX");
        imageLabel.getActionMap().put("flipImageX", flipImageXAction);

        if (currentImage != null) { // Gets image information
            drawingImage = new BufferedImage(currentImage.getWidth(), currentImage.getHeight(), BufferedImage.TYPE_INT_ARGB);
        }
    }

    /**
     * Initializes the selection process. Allows users to select an area on the image.
     */
    private void startSelection() {
        isSelecting = true;
        isSelectionMode = true; // Enable selection mode
        selectionStartX = -1; // Initialize selection coordinates
        selectionStartY = -1;
        selectionEndX = -1;
        selectionEndY = -1;

        // Add a mouse listener to the imageLabel for selecting the area
        imageLabel.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                if (isSelecting) {
                    selectionStartX = e.getX();
                    selectionStartY = e.getY();
                }
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                if (isSelecting) {
                    selectionEndX = e.getX();
                    selectionEndY = e.getY();
                    isSelecting = false; // End the selection
                    cutSelection();
                    isSelectionMode = false; // Disable selection mode
                }
            }
        });
    }

    private void autosave() {
        if (unsavedChanges) {
            // Check if there are unsaved changes
            saveImage(); // Save the current image
        }
    }



    private void showAutosaveNotification() {
        // Check if the autosave notification should be displayed
        if (autosaveNotificationEnabled) {
            JDialog autosaveDialog = new JDialog(this, "Autosave Notification", Dialog.ModalityType.MODELESS);
            autosaveDialog.setSize(300, 100);

            JLabel notificationLabel = new JLabel("Autosave triggered!");
            notificationLabel.setHorizontalAlignment(SwingConstants.CENTER);
            autosaveDialog.add(notificationLabel);

            autosaveDialog.setVisible(true);

            // Create a timer to close the notification after 2 seconds
            Timer closeTimer = new Timer(2000, e -> {
                autosaveDialog.dispose(); // Close the dialog
            });
            closeTimer.setRepeats(false); // Execute only once
            closeTimer.start();
        }
    }



    /**
     * Cuts the selected region from the drawingImage and stores it in the clipboard.
     */
    private void cutSelection() {
        if (selectionStartX >= 0 && selectionStartY >= 0 && selectionEndX >= 0 && selectionEndY >= 0) {
            // Create a BufferedImage to hold the selected region
            int width = Math.abs(selectionEndX - selectionStartX);
            int height = Math.abs(selectionEndY - selectionStartY);
            BufferedImage selectedImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);

            // Copy the selected region from the drawingImage to the selectedImage
            Graphics2D g2d = selectedImage.createGraphics();
            g2d.drawImage(drawingImage.getSubimage(Math.min(selectionStartX, selectionEndX), Math.min(selectionStartY, selectionEndY), width, height), 0, 0, null);
            g2d.dispose();

            // Remove the selected region from the drawingImage (clear it)
            g2d = (Graphics2D) drawingImage.getGraphics();
            g2d.setComposite(AlphaComposite.Clear);
            g2d.fillRect(Math.min(selectionStartX, selectionEndX), Math.min(selectionStartY, selectionEndY), width, height);
            g2d.dispose();

            // Store the selectedImage to the clipboard for later pasting
            clipboardImage = selectedImage;

            // Repaint the label to reflect the changes
            imageLabel.repaint();
        }
    }

    /**
     * Pastes the clipboard image onto the drawing image at the specified location.
     */
    private void pasteClipboardImage() {
        if (clipboardImage != null && drawingImage != null) {
            // Determine the paste location (replace these values with your actual logic)
            int x = startX; // Replace with the actual paste coordinates
            int y = startY; // Replace with the actual paste coordinates

            // Paste the clipboard image onto the drawing image
            Graphics2D g2d = (Graphics2D) drawingImage.getGraphics();
            g2d.drawImage(clipboardImage, x, y, null);
            g2d.dispose();

            // Repaint the label to reflect the changes
            imageLabel.repaint();
        }
    }

    /**
     * Opens a color chooser dialog for selecting the drawing color.
     */
    private void selectColor() {
        Color selectedColor = JColorChooser.showDialog(this, "Select Color", drawingColor);
        if (selectedColor != null) {
            // Update the drawing color
            drawingColor = selectedColor;
        }
    }

    /**
     * Displays information about the current drawing color, including name, hex, and RGB values.
     */
    private void showColorInfo() { // Gets color name, hex, and RGB values
        String colorName = getColorName(drawingColor);
        String hexValue = String.format("#%02X%02X%02X", drawingColor.getRed(), drawingColor.getGreen(), drawingColor.getBlue());
        String rgbValue = String.format("RGB(%d, %d, %d)", drawingColor.getRed(), drawingColor.getGreen(), drawingColor.getBlue());
        String colorInfo = "Color Name: " + colorName + "\n"
                + "Hex Value: " + hexValue + "\n"
                + "RGB Value: " + rgbValue;
        JOptionPane.showMessageDialog(this, colorInfo, "Color Info", JOptionPane.INFORMATION_MESSAGE);
    }

    /**
     * Gets the English name for a color based on its current value.
     *
     * @param color The color for which to determine the name.
     * @return The English name of the color.
     */
    private String getColorName(Color color) { // Gets english name for color based on current color value
        if (color.equals(Color.BLACK)) {
            return "Black";
        } else if (color.equals(Color.RED)) {
            return "Red";
        } else if (color.equals(Color.GREEN)) {
            return "Green";
        } else if (color.equals(Color.BLUE)) {
            return "Blue";
        } else {
            return "Custom Color";
        }
    }

    /**
     * Loads and displays an image from a specified file.
     *
     * @param selectedFile The file containing the image to be loaded and displayed.
     * @throws IOException If an error occurs while loading the image.
     */
    private void loadAndDisplayImage(File selectedFile) throws IOException {
        // Check the file format
        String format = getFileFormat(selectedFile);
        if (format != null) {
            currentImage = ImageIO.read(selectedFile);
            ImageIcon imageIcon = new ImageIcon(currentImage);
            imageLabel.setIcon(imageIcon);
        } else {
            JOptionPane.showMessageDialog(this, "Unsupported image format.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Starts a new drawing, clearing the canvas and resetting various parameters.
     */
    private void startNewDrawing() {
        int option = JOptionPane.showConfirmDialog(
                this,
                "Are you sure you want to start a new drawing? Any unsaved changes will be lost.",
                "Confirm Start New Drawing",
                JOptionPane.YES_NO_OPTION
        );
        if (option == JOptionPane.YES_OPTION) {
            // Perform a smart save if there are unsaved changes for the currentImage
            if (currentImage != null && unsavedChanges) {
                saveAsImage();
            }
            // Get the screen dimensions
            Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
            // Set the canvas dimensions to fill the screen
            int canvasWidth = (int) screenSize.getWidth();
            int canvasHeight = (int) screenSize.getHeight();
            // Create a new blank canvas with screen dimensions
            drawingImage = new BufferedImage(canvasWidth, canvasHeight, BufferedImage.TYPE_INT_ARGB);
            // Clear the canvas (fill it with a transparent background)
            Graphics2D g2d = drawingImage.createGraphics();
            g2d.setColor(new Color(0, 0, 0, 0)); // Transparent color
            g2d.fillRect(0, 0, canvasWidth, canvasHeight);
            g2d.dispose();
            // Update the displayed image and resize the label
            imageLabel.setIcon(new ImageIcon(drawingImage));
            imageLabel.setPreferredSize(new Dimension(canvasWidth, canvasHeight));
            imageLabel.revalidate();
            // Clear any previous image references
            currentImage = null;
            savedFile = null;
            // Optionally, reset other drawing-related variables or options here
            // Inform the user that a new drawing has started
            unsavedChanges = false; // Reset the unsaved changes flag since it's a new drawing
            JOptionPane.showMessageDialog(this, "A new drawing has started.", "New Drawing", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    /**
     * Saves the current image. Prompts the user to choose a location if necessary.
     */
    private void saveImage() {
        if (currentImage != null && savedFile != null) {
            try {
                showAutosaveNotification();
                String format = getFileFormat(savedFile);
                if (format != null) {
                    BufferedImage copyImage = new BufferedImage(currentImage.getWidth(), currentImage.getHeight(), BufferedImage.TYPE_INT_ARGB);
                    Graphics2D g2d = copyImage.createGraphics();
                    g2d.drawImage(currentImage, 0, 0, null);
                    g2d.drawImage(drawingImage, 0, 0, null);
                    g2d.dispose();
                    ImageIO.write(copyImage, format, savedFile);
                } else {
                    JOptionPane.showMessageDialog(this, "Unsupported image format.", "Error", JOptionPane.ERROR_MESSAGE);
                }
                autosaveTimeInSeconds = 0;
            } catch (IOException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error saving image.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            saveAsImage(); // If currentImage is null, use Save As
        }
    }

    /**
     * Undoes the last action, restoring the previous state of the drawing.
     */
    private void undo() {
        if (!undoStack.isEmpty()) {
            BufferedImage previousState = undoStack.pop();
            redoStack.push(deepCopy(drawingImage)); // Capture the current state for redo
            drawingImage = previousState;
            imageLabel.repaint();
        }
    }

    /**
     * Redoes the last undone action, restoring the next state of the drawing.
     */
    private void redo() {
        if (!redoStack.isEmpty()) {
            BufferedImage nextState = redoStack.pop();
            undoStack.push(deepCopy(drawingImage)); // Capture the current state for undo
            drawingImage = nextState;
            imageLabel.repaint();
        }
    }

    /**
     * Creates a deep copy of a BufferedImage.
     *
     * @param source The source image to be copied.
     * @return A deep copy of the source image.
     */
    private BufferedImage deepCopy(BufferedImage source) {
        if (source == null) {
            return null;
        }
        BufferedImage copy = new BufferedImage(source.getWidth(), source.getHeight(), source.getType());
        Graphics2D g = copy.createGraphics();
        g.drawImage(source, 0, 0, null);
        g.dispose();
        return copy;
    }

    private void saveAsImage() {
        if (drawingImage != null) {
            JFileChooser fileChooser = new JFileChooser();
            int result = fileChooser.showSaveDialog(this);
            if (result == JFileChooser.APPROVE_OPTION) {
                savedFile = fileChooser.getSelectedFile();
                try {
                    String format = getFileFormat(savedFile);
                    if (format != null) {
                        ImageIO.write(drawingImage, format, savedFile);
                        JOptionPane.showMessageDialog(this, "Image saved successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
                        unsavedChanges = false; // Reset the unsaved changes flag after saving
                    } else {
                        JOptionPane.showMessageDialog(this, "Unsupported image format.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                    JOptionPane.showMessageDialog(this, "Error saving image.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }

    /**
     * Displays a help window with information about available commands and common questions.
     */
    private void showHelp() { // function to display window with help text
        // Create a new window to display help text
        JFrame helpFrame = new JFrame("Help");
        JTextArea helpText = new JTextArea("""
                Here are all the available commands and the explanation of their functionality

                Save- Re-saves the image at the same location with the same name
                           You must Save As before you can save the picture
                Save As- Saves the image after specifying name and location
                Color Wheel- allows you to change the color you draw in
                Line Width- Adjust the width of the line you are drawing
                Help- Displays the help window


                Common questions (and answers)
                             
                How do I draw?
                Hold left mouse button and drag the mouse around the screen to draw

                What files types does this program support?
                This program can handle PNG, JPG, and BMP image types

                How did you code this so well?
                Because I had a good "inheritance"
                          
                         
                What shortcuts are there
                Ctrl + H         = Help
                Ctrl + Shift + S = Save As
                Ctrl + S         = Save
                Ctrl + I         = Color Info
                Ctrl + Shift + C = Color chooser
                """);
        helpText.setEditable(false);
        helpFrame.add(new JScrollPane(helpText));
        helpFrame.setSize(1000, 800);
        helpFrame.setVisible(true);
    }

    /**
     * Gets the lowercase format of a file based on its extension.
     *
     * @param file The file to check for its format.
     * @return The lowercase format of the file (e.g., "jpg", "png", "webp").
     */
    private String getFileFormat(File file) {
        String fileName = file.getName();
        int dotIndex = fileName.lastIndexOf(".");
        if (dotIndex > 0) {
            return fileName.substring(dotIndex + 1).toLowerCase();
        }
        return null;
    }

    /**
     * Toggles between solid and dashed line/shape outlines based on user preference.
     *
     * @param enableDashedLines True to enable dashed lines, false for solid lines.
     */
    private void toggleDashedLines(boolean enableDashedLines) { // Function to toggle between solid and dashed line/shape outlines
        // Set the line style for shapes based on the selection
        if (enableDashedLines) {
            dashedLineStroke = new BasicStroke(lineWidth, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, 0, new float[]{5}, 0);
        } else {
            dashedLineStroke = null;
        }
    }

    /**
     * Draws various shapes on the canvas, including lines, squares, circles, etc.
     */
    private void drawShape() { // Function to draw shapes, uses switch cases based on selected button from Shapes tab
        if (isSelectionMode) {
            // If in selection mode, do nothing (disable freehand drawing)
            return;
        }

        if (drawingImage != null) {
            Graphics2D g2d = (Graphics2D) drawingImage.getGraphics();
            g2d.setColor(drawingColor); // Set the drawing color
            g2d.setStroke(dashedLineStroke != null ? dashedLineStroke : new BasicStroke(lineWidth)); // Use the selected line style
            if (selectedShape == ImageEdit.Shape.ERASE) {
                // When ERASE is selected, use the eraserWidth for erasing
                g2d.setComposite(AlphaComposite.Clear);
                g2d.fillRect(prevX - (eraserWidth / 2), prevY - (eraserWidth / 2), eraserWidth, eraserWidth);
            } else {

                switch (selectedShape) {
                    case LINE -> g2d.drawLine(startX, startY, prevX, prevY);
                    case SQUARE -> {
                        int size = Math.max(Math.abs(prevX - startX), Math.abs(prevY - startY));
                        g2d.drawRect(startX, startY, size, size);
                    }
                    case CIRCLE -> {
                        int diameter = Math.max(Math.abs(prevX - startX), Math.abs(prevY - startY));
                        g2d.drawOval(startX, startY, diameter, diameter);
                    }
                    case RECTANGLE -> {
                        int width = Math.abs(prevX - startX);
                        int height = Math.abs(prevY - startY);
                        g2d.drawRect(startX, startY, width, height);
                    }
                    case ELLIPSE -> {
                        int ellipseWidth = Math.abs(prevX - startX);
                        int ellipseHeight = Math.abs(prevY - startY);
                        g2d.drawOval(startX, startY, ellipseWidth, ellipseHeight);
                    }
                    case TRIANGLE -> {
                        int[] xPoints = {startX, prevX, startX - (prevX - startX)};
                        int[] yPoints = {startY, prevY, prevY};
                        g2d.drawPolygon(xPoints, yPoints, 3);
                    }
                    case POINTER -> {
                        int[] xPoints2 = {startX, (startX + prevX) / 2, prevX, (startX + prevX) / 2};
                        int[] yPoints2 = {startY, prevY, startY, prevY};
                        // Draw the pointer
                        g2d.drawPolygon(xPoints2, yPoints2, 4);
                    }
                    case FREEHAND -> {
                    }
                    // Freehand is drawn while dragging, handled in mouseDragged
                    case TEXT -> {
                        String userInput = JOptionPane.showInputDialog(this, "Enter your text:");
                        if (userInput != null && !userInput.isEmpty()) {
                            g2d.setFont(new Font("Arial", Font.PLAIN, 20)); // Customize the font and size as needed
                            g2d.drawString(userInput, startX, startY);
                        }
                    }
                    case POLYGON -> {
                        if (polygonSides >= 3) { // Ensure there are at least 3 sides
                            double angle = 2 * Math.PI / polygonSides;
                            int[] xPointsPoly = new int[polygonSides];
                            int[] yPointsPoly = new int[polygonSides];
                            double currentAngle = 0;
                            for (int i = 0; i < polygonSides; i++) {
                                xPointsPoly[i] = (int) (startX + Math.cos(currentAngle) * (prevX - startX));
                                yPointsPoly[i] = (int) (startY + Math.sin(currentAngle) * (prevY - startY));
                                currentAngle += angle;
                            }
                            g2d.drawPolygon(xPointsPoly, yPointsPoly, polygonSides);
                        }
                    }
                }
            }

            g2d.dispose();
            imageLabel.repaint();
            unsavedChanges = true; // Mark changes as unsaved
        }
    }

    enum ShapeType { RECTANGLE, CIRCLE, LINE, ELLIPSE, TRIANGLE, POLYGON, POINTER, SQUARE } // Added SQUARE

    // Create a BufferedImage with the desired shape and size
    private static Icon createShapeIcon(int width, int height, ShapeType shapeType) {
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = image.createGraphics();

        g2d.setColor(Color.BLACK); // Set the shape color

        // Draw the selected shape
        switch (shapeType) {
            case RECTANGLE:
                g2d.fillRect(0, 0, width, height);
                break;
            case CIRCLE:
                g2d.fillOval(0, 0, width, height);
                break;
            case LINE:
                g2d.drawLine(0, height / 2, width, height / 2);
                break;
            case ELLIPSE:
                g2d.fillOval(0, 0, width, height / 2);
                break;
            case TRIANGLE:
                int[] xPoints = {width / 2, 0, width};
                int[] yPoints = {0, height, height};
                g2d.fillPolygon(xPoints, yPoints, 3);
                break;
            case POLYGON:
                int sides = 6; // Change the number of sides as needed
                double angle = 2 * Math.PI / sides;
                int[] xPointsPoly = new int[sides];
                int[] yPointsPoly = new int[sides];
                double currentAngle = 0;
                for (int i = 0; i < sides; i++) {
                    xPointsPoly[i] = (int) (width / 2 + Math.cos(currentAngle) * (width / 2));
                    yPointsPoly[i] = (int) (height / 2 + Math.sin(currentAngle) * (height / 2));
                    currentAngle += angle;
                }
                g2d.fillPolygon(xPointsPoly, yPointsPoly, sides);
                break;
            case POINTER:
                int[] xPointsPointer = {width / 2, 0, width / 2, width};
                int[] yPointsPointer = {0, height / 2, height, height / 2};
                g2d.fillPolygon(xPointsPointer, yPointsPointer, 4);
                break;
            case SQUARE:
                g2d.fillRect(0, 0, width, height); // Added square
                break;
        }

        g2d.dispose();
        return new ImageIcon(image);
    }

    /**
     * Prompts the user to save changes before closing the window if there are unsaved modifications.
     */
    private void closeWindow() {
        if (unsavedChanges) {
            int option = JOptionPane.showConfirmDialog(
                    this,
                    "Do you want to save your changes before closing?",
                    "Unsaved Changes",
                    JOptionPane.YES_NO_CANCEL_OPTION
            );
            if (option == JOptionPane.YES_OPTION) {
                saveImage();
                autosaveTimer.stop(); // Stop the autosave timer
                dispose();
            } else if (option == JOptionPane.NO_OPTION) {
                autosaveTimer.stop(); // Stop the autosave timer
                dispose();
            }
            // If option is CANCEL_OPTION, do nothing and keep the window open.
        } else {
            autosaveTimer.stop(); // Stop the autosave timer
            dispose();
        }
    }
    private static Icon createFreehandIcon() {
        BufferedImage image = new BufferedImage(30, 30, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = image.createGraphics();

        g2d.setColor(Color.BLACK); // Set the pencil color

        // Draw a simple pencil shape
        g2d.fillRect(5, 5, 5, 20); // Pencil body
        g2d.drawLine(5, 25, 5, 30); // Pencil tip

        g2d.dispose();
        return new ImageIcon(image);
    }
    private void initializeAutosaveTimerWindow() {
        autosaveTimerWindow = new JFrame("Autosave Timer");
        autosaveTimerWindow.setSize(200, 100);
        autosaveTimerWindow.setLocationRelativeTo(this);

        // Create a label to display the timer value
        JLabel timerLabel = new JLabel("Autosave Timer: 0s");
        autosaveTimerWindow.add(timerLabel);

        autosaveUpdateTimer = new Timer(1000, e -> {
            // Update the autosave time and label text every second
            autosaveTimeInSeconds++;
            timerLabel.setText("Autosave Timer: " + autosaveTimeInSeconds + "s");
        });
        autosaveUpdateTimer.start();

        autosaveTimerWindow.setVisible(autosaveTimerVisible);
    }

    private void toggleAutosaveTimerWindow() {
        autosaveTimerVisible = !autosaveTimerVisible;
        autosaveTimerWindow.setVisible(autosaveTimerVisible);
    }

    private BufferedImage rotateImage(BufferedImage image, double angle) {
        int width = image.getWidth();
        int height = image.getHeight();
        BufferedImage rotatedImage = new BufferedImage(height, width, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = rotatedImage.createGraphics();
        g2d.translate((height - width) / 2, (width - height) / 2);
        g2d.rotate(Math.toRadians(angle), width / 2, height / 2);
        g2d.drawRenderedImage(image, null);
        g2d.dispose();
        return rotatedImage;
    }

    private BufferedImage flipImageY(BufferedImage image) {
        int width = image.getWidth();
        int height = image.getHeight();
        BufferedImage flippedImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = flippedImage.createGraphics();
        g2d.drawImage(image, width, 0, 0, height, 0, 0, width, height, null);
        g2d.dispose();
        return flippedImage;
    }

    private BufferedImage flipImageX(BufferedImage image) {
        int width = image.getWidth();
        int height = image.getHeight();
        BufferedImage flippedImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = flippedImage.createGraphics();
        g2d.drawImage(image, 0, height, width, 0, 0, 0, width, height, null);
        g2d.dispose();
        return flippedImage;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            ImageEdit imageEdit = new ImageEdit();
            imageEdit.initializeAutosaveTimerWindow(); // Initialize the autosave timer window
            imageEdit.setVisible(true);
        });
    }
}