import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;

/**
 * This class contains methods for creating and managing UI components in the image editing application.
 */
public class UIComponents {

    // Enumeration for shape types
    public enum ShapeType { RECTANGLE, CIRCLE, LINE, ELLIPSE, TRIANGLE, POLYGON, POINTER, SQUARE }

    public static Icon createShapeIcon(int width, int height, ShapeType shapeType) {
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = image.createGraphics();
        g2d.setColor(Color.BLACK); // Set the shape color

        // Draw the selected shape
        switch (shapeType) {
            case RECTANGLE:
                g2d.drawRect(0, 0, width - 1, height - 1);
                break;
            case CIRCLE:
                g2d.drawOval(0, 0, width - 1, height - 1);
                break;
            case LINE:
                g2d.drawLine(0, 0, width, height);
                break;
            case ELLIPSE:
                g2d.drawOval(0, 0, width - 1, height / 2);
                break;
            case TRIANGLE:
                g2d.drawPolygon(new int[]{0, width / 2, width}, new int[]{height, 0, height}, 3);
                break;
            case POLYGON:
                // Example for a hexagon
                int sides = 6;
                int[] xPoints = new int[sides];
                int[] yPoints = new int[sides];
                for (int i = 0; i < sides; i++) {
                    xPoints[i] = (int) (width / 2 + width / 2 * Math.cos(i * 2 * Math.PI / sides));
                    yPoints[i] = (int) (height / 2 + height / 2 * Math.sin(i * 2 * Math.PI / sides));
                }
                g2d.drawPolygon(xPoints, yPoints, sides);
                break;
            case POINTER:
                g2d.drawLine(width / 2, 0, width / 2, height);
                g2d.drawLine(0, height / 2, width, height / 2);
                break;
            case SQUARE:
                g2d.drawRect(0, 0, width - 1, width - 1);
                break;
        }

        g2d.dispose();
        return new ImageIcon(image);
    }

    /**
     * Creates an icon for the freehand drawing tool.
     *
     * @return An icon representing the freehand drawing tool.
     */
    public static Icon createFreehandIcon() {
        BufferedImage image = new BufferedImage(30, 30, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = image.createGraphics();

        g2d.setColor(Color.BLACK); // Set the pencil color
        // Draw a simple pencil shape
        g2d.fillRect(5, 5, 20, 5); // Pencil body
        g2d.fillPolygon(new int[]{5, 25, 25}, new int[]{5, 5, 10}, 3); // Pencil tip

        g2d.dispose();
        return new ImageIcon(image);
    }

    /**
     * Initializes and shows the autosave timer window.
     *
     * @param autosaveTimerVisible A boolean to indicate if the window should be visible.
     * @return The initialized autosave timer window.
     */
    public static JFrame initializeAutosaveTimerWindow(boolean autosaveTimerVisible) {
        JFrame autosaveTimerWindow = new JFrame("Autosave Timer");
        autosaveTimerWindow.setSize(200, 100);
        autosaveTimerWindow.setLocationRelativeTo(null);

        // Create and add components to the window
        JLabel timerLabel = new JLabel("Autosave Timer: 0s");
        autosaveTimerWindow.add(timerLabel);

        autosaveTimerWindow.setVisible(autosaveTimerVisible);
        return autosaveTimerWindow;
    }
}
