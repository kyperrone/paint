import java.awt.*;
import java.awt.image.BufferedImage;

/**
 * This class contains operations for manipulating images in the image editing application.
 */
public class ImageOperations {

    /**
     * Creates a deep copy of a BufferedImage.
     *
     * @param source The source image to be copied.
     * @return A deep copy of the source image.
     */
    public static BufferedImage deepCopy(BufferedImage source) {
        if (source == null) {
            return null;
        }
        BufferedImage copy = new BufferedImage(source.getWidth(), source.getHeight(), source.getType());
        Graphics2D g = copy.createGraphics();
        g.drawImage(source, 0, 0, null);
        g.dispose();
        return copy;
    }

    /**
     * Rotates an image by a specified angle.
     *
     * @param image The image to rotate.
     * @param angle The angle in degrees.
     * @return The rotated image.
     */
    public static BufferedImage rotateImage(BufferedImage image, double angle) {
        int width = image.getWidth();
        int height = image.getHeight();
        BufferedImage rotatedImage = new BufferedImage(height, width, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = rotatedImage.createGraphics();
        g2d.translate((height - width) / 2, (width - height) / 2);
        g2d.rotate(Math.toRadians(angle), width / 2, height / 2);
        g2d.drawRenderedImage(image, null);
        g2d.dispose();
        return rotatedImage;
    }

    /**
     * Flips an image horizontally (over the Y-axis).
     *
     * @param image The image to flip.
     * @return The flipped image.
     */
    public static BufferedImage flipImageY(BufferedImage image) {
        int width = image.getWidth();
        int height = image.getHeight();
        BufferedImage flippedImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = flippedImage.createGraphics();
        g2d.drawImage(image, width, 0, 0, height, 0, 0, width, height, null);
        g2d.dispose();
        return flippedImage;
    }

    /**
     * Flips an image vertically (over the X-axis).
     *
     * @param image The image to flip.
     * @return The flipped image.
     */
    public static BufferedImage flipImageX(BufferedImage image) {
        int width = image.getWidth();
        int height = image.getHeight();
        BufferedImage flippedImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = flippedImage.createGraphics();
        g2d.drawImage(image, 0, height, width, 0, 0, 0, width, height, null);
        g2d.dispose();
        return flippedImage;
    }
}
