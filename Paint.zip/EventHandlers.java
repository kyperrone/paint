import java.awt.*;
import java.awt.event.*;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;
import javax.swing.*;

/**
 * This class contains methods for handling events in the image editing application.
 */
public class EventHandlers {

    /**
     * Initializes the selection process. Allows users to select an area on the image.
     * @param imageLabel The label containing the image.
     * @param isSelecting Flag indicating if selection is ongoing.
     * @param selectionStartX Start X coordinate of the selection.
     * @param selectionStartY Start Y coordinate of the selection.
     * @param selectionEndX End X coordinate of the selection.
     * @param selectionEndY End Y coordinate of the selection.
     */
    public static void startSelection(JLabel imageLabel, boolean isSelecting, int selectionStartX, int selectionStartY, int selectionEndX, int selectionEndY) {
        imageLabel.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                if (isSelecting) {
                    selectionStartX = e.getX();
                    selectionStartY = e.getY();
                }
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                if (isSelecting) {
                    selectionEndX = e.getX();
                    selectionEndY = e.getY();
                    isSelecting = false; // End the selection
                    // Further action to process the selection
                }
            }
        });
    }

    /**
     * Autosaves the current image.
     * @param unsavedChanges Flag indicating if there are unsaved changes.
     */
    public static void autosave(boolean unsavedChanges, BufferedImage currentImage, File savedFile) {
        if (unsavedChanges && currentImage != null && savedFile != null) {
            try {
                String format = getFileFormat(savedFile); // Implement getFileFormat to determine the image format
                ImageIO.write(currentImage, format, savedFile);
                // Optionally, show an autosave notification
            } catch (IOException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error autosaving file.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    /**
     * Gets the format of the image file.
     *
     * @param file The image file.
     * @return The format name of the image (e.g., "png", "jpg").
     */
    private static String getFileFormat(File file) {
        String fileName = file.getName();
        int dotIndex = fileName.lastIndexOf(".");
        if (dotIndex > 0) {
            return fileName.substring(dotIndex + 1).toLowerCase();
        }
        return "png"; // Default format
    }

    /**
     * Shows a notification for autosave.
     * @param autosaveNotificationEnabled Flag indicating if autosave notification is enabled.
     */
    public static void showAutosaveNotification(boolean autosaveNotificationEnabled) {
        if (autosaveNotificationEnabled) {
            JOptionPane.showMessageDialog(null, "Autosave Complete", "Notification", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    /**
     * Cuts the selected region from the drawingImage and stores it in the clipboard.
     * @param clipboardImage Image to store in the clipboard.
     * @param drawingImage Image from which to cut.
     * @param selectionStartX Start X coordinate of the selection.
     * @param selectionStartY Start Y coordinate of the selection.
     * @param selectionEndX End X coordinate of the selection.
     * @param selectionEndY End Y coordinate of the selection.
     */
    public static BufferedImage cutSelection(BufferedImage clipboardImage, BufferedImage drawingImage, int selectionStartX, int selectionStartY, int selectionEndX, int selectionEndY) {
        int width = Math.abs(selectionEndX - selectionStartX);
        int height = Math.abs(selectionEndY - selectionStartY);
        BufferedImage selectedImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);

        Graphics2D g2d = selectedImage.createGraphics();
        g2d.drawImage(drawingImage.getSubimage(Math.min(selectionStartX, selectionEndX), Math.min(selectionStartY, selectionEndY), width, height), 0, 0, null);
        g2d.dispose();

        g2d = (Graphics2D) drawingImage.getGraphics();
        g2d.setComposite(AlphaComposite.Clear);
        g2d.fill(new Rectangle2D.Float(Math.min(selectionStartX, selectionEndX), Math.min(selectionStartY, selectionEndY), width, height));
        g2d.dispose();

        return selectedImage;
    }

    /**
     * Pastes the clipboard image onto the drawing image at the specified location.
     * @param clipboardImage Image from the clipboard to paste.
     * @param drawingImage Image onto which to paste the clipboard image.
     * @param startX X coordinate where the image should be pasted.
     * @param startY Y coordinate where the image should be pasted.
     */
    public static void pasteClipboardImage(BufferedImage clipboardImage, BufferedImage drawingImage, int startX, int startY) {
        if (clipboardImage != null && drawingImage != null) {
            Graphics2D g2d = (Graphics2D) drawingImage.getGraphics();
            g2d.drawImage(clipboardImage, startX, startY, null);
            g2d.dispose();
        }
    }
}
